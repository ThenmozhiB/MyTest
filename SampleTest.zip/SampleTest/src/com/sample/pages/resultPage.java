package com.sample.pages;

import java.awt.*;
import java.util.List;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class resultPage{

	
	@FindBy(xpath="//*[@id='bcKwText']/span")
	private WebElement searchResult;
	
	@FindBy(css="h2.a-size-medium.s-inline.s-access-title.a-text-normal")
	private List<WebElement> bookTitle;
	
	@FindBy(xpath="//li[@id='result_0']/div/div/div/div[2]/div[1]/div[2]/span")
	private List<WebElement> author;
	
	@FindBy(xpath="//li[@id='result_0']/div/div/div/div[2]/div[2]/span")
	private WebElement shippment;
	
	@FindBy(xpath="//li[@id='result_0']/div/div/div/div[2]/div[3]/div[2]/div/a")
	private WebElement noOfReviewers;
	
	@FindBy(xpath="//*[@id='a-popover-content-3']/div/div/div/div[1]/span")
	private WebElement review;
	
	@FindBy(xpath="//li[@id='result_0']/div/div/div/div[2]/div[3]/div[2]/div/span/span/a/i[2]")
	private WebElement expandReview;
	
	String bookName;
	
	
	
	WebDriverWait wait;
	 public resultPage(WebDriver driver){
		 	
	        PageFactory.initElements(driver, this);
	        wait=new WebDriverWait(driver, 30);
	    }
	
	
   
    public boolean checkCurrentURL(String[] key, WebDriver driver){
    	
    	String currentURL = driver.getCurrentUrl();
	    boolean f=false;
   	    for(String k:key)
   	    {
   	    	if(currentURL.contains(k))
   	    		f=true;
   	    	else
   	    		return false;
   	    		
   	    }
   	    return f;
    	
    } 
    
    
    public boolean checkBookTitle(String[] key)
    {
    	bookName= bookTitle.get(0).getAttribute("data-attribute");
    	System.out.println("BookName: " + bookName);
   
      	    for(String k:key)
      	    {																	//check book title contains either of Data or Catalog
      	    	if(bookName.contains(k))
      	    		return true;
      	    		
      	    }
      	    return false;  
     }
    
    public boolean checkSearchResult(String resultVal){
    //	wait.until(ExpectedConditions.visibilityOf(searchResult));
    	System.out.println(searchResult.getText());
    	return searchResult.getText().contains("Data");
    }
    
    public void authorName(){
    	System.out.print("\n Author(s): " );
    	for(int i=1; i<author.size();i++)
    	System.out.print(" " + author.get(i).getText());
    	
    }
    
        private void getDetails(WebDriver driver,String succXpath){
        	WebElement ele= driver.findElement(By.xpath("//li[@id='result_0']/div/div/div/div[2]/div[3]/div[1]/div"+succXpath));
        	System.out.print(ele.getText());
        }
        
        private void getReviewDetails(WebDriver driver){
        	try {
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='histogramTable']/tbody"))));
	        	for(int i=1;i<=5;i++)
	        	{
	        		WebElement element1= driver.findElement(By.xpath("//*[@id='histogramTable']/tbody/tr["+i+"]/td[3]/span[2]"));
		        	if(element1.getText().contains("0%"))
		        	{
		        		System.out.println((6-i) +" stars represent 0% of rating");
		        	}else{
	        	WebElement element2= driver.findElement(By.xpath("//*[@id='histogramTable']/tbody/tr["+i+"]/td[1]/span[1]/a"));
	        	System.out.println(element2.getAttribute("title"));
		        	}
	        	}
			} catch (InterruptedException e) {
				e.printStackTrace();
			};
        	
        	}
        
        public void firstEdition(WebDriver driver)
        {
        	System.out.print("\n Edition Details: ");
        	getDetails(driver,"[1]/a/h3");
        	System.out.print("\n Rate: ");
        	getDetails(driver,"[2]/a/span[2]/span/sup[1]");
        	getDetails(driver,"[2]/a/span[2]/span/span");
        	System.out.print(".");
        	getDetails(driver,"[2]/a/span[2]/span/sup[2]");
        	System.out.print("\n Actual Rate: ");
        	getDetails(driver,"[2]/span[2]");
        	System.out.print("\n Stock Detail: ");
        	getDetails(driver,"[3]/span");
        	
        }
        
        public void secondEdition(WebDriver driver)
        {
        	System.out.print("\n Edition Details: ");
        	getDetails(driver,"[5]/a/h3");
        	System.out.print("\n Rate: ");
        	getDetails(driver,"[6]/a/span[2]/span/sup[1]");
        	getDetails(driver,"[6]/a/span[2]/span/span");
        	System.out.print(".");
        	getDetails(driver,"[6]/a/span[2]/span/sup[2]");
        	System.out.print("\n Get it By: ");
        	getDetails(driver,"[7]/span/span");
        	        	
        }
        
        public void otherDetails(WebDriver driver)
        {
        	System.out.print("\n ");
        	getDetails(driver,"[4]/div[1]/span");
        	System.out.print("\n Rate: ");
        	getDetails(driver,"[4]/div[2]/a/span[2]");
        	System.out.print("\n ");
        	getDetails(driver,"[4]/div[2]/a");
        	
        }
        
        public void reviewDetails(WebDriver driver)
        {
        	System.out.print("\n Review Details \n");
           	System.out.print("\n No. of Reviewers: ");
        	System.out.println(noOfReviewers.getText());
        	expandReview.click(); 
        	Actions builder = new Actions (driver);							
            builder.clickAndHold().moveToElement(expandReview);					
            builder.moveToElement(expandReview).build().perform(); 
        	getReviewDetails(driver);
        	System.out.println(review.getText());
        	
        }
			
			
}
   



