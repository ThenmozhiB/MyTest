package com.sample.pages;


import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class homePage{

	@FindBy(id="nav-search")
	private WebElement searchBar;
	
	@FindBy(id="searchDropdownBox")
	private WebElement dropdown;
	
	@FindBy(id="twotabsearchtextbox")
	private WebElement searchField;
	
	@FindBy(css="div.nav-search-submit input.nav-input")
	private WebElement search;
	
	 public homePage(WebDriver driver){

	        PageFactory.initElements(driver, this);
	    }
	
	public boolean isSearchBarPresent(){
    	return searchBar.isDisplayed();
    }
   
    public void selectDropDownValue(String optionVal){
    	Select select=new Select(dropdown);
    	select.selectByVisibleText(optionVal);
    	
    }  	
    public void setSearch(String searchVal){
    	searchField.sendKeys(searchVal);
    }
    public void clickSearch(){
    	search.click();
    }
        
			
}
   



