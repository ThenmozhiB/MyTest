package com.sample.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.sample.pages.homePage;
import com.sample.pages.resultPage;
public class searchTest extends baseTest {

	private String baseUrl="https://www.amazon.com/";
	homePage homePg;
	resultPage resultPg;
	WebDriver driver;
	private String searchString="Data Catalog";
	@BeforeTest
	public void ainitial()
	{
	getBaseUrl(baseUrl);
	driver= getCurrDriver();
	homePg=PageFactory.initElements(driver, homePage.class);
	resultPg=PageFactory.initElements(driver, resultPage.class);
	 
	}
	@Test
	public void Test1()
	{	
					
	 Assert.assertTrue(homePg.isSearchBarPresent(),"Search Bar is not Present");
		try{
		 homePg.selectDropDownValue("Books");	// Selects Books from search dropdown		 
		 homePg.setSearch(searchString);		// Give book name or any search details
		 homePg.clickSearch();
		}
		 catch (Exception e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	}
	@Test
	public void Test2()
	{	
	
		Assert.assertTrue(resultPg.checkSearchResult(searchString),"Search Result is not matching");   				//check search result is same as searchstring
		String[] splitedKey = searchString.split("\\s+");
		Assert.assertTrue(resultPg.checkCurrentURL(splitedKey, driver),"URL is not correct");						//check URL has search keyword
		Assert.assertTrue(resultPg.checkBookTitle(splitedKey),"Listed book is not matching related search");		// check Book is related to search
		resultPg.authorName();
		resultPg.firstEdition(driver); 													//Record other details of book
		resultPg.secondEdition(driver);
		resultPg.otherDetails(driver);
		
		resultPg.reviewDetails(driver);
		
	
	}
	@AfterTest
	public void lastTest()
	{
	driver.quit();
	}
	

}

