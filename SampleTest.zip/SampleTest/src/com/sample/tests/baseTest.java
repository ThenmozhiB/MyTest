package com.sample.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;


public class baseTest {
	 private WebDriver driver;

	    protected WebDriver getCurrDriver() {
	        if (driver != null) {
	            return driver;
	        }
	        String path = System.getProperty("user.dir");
	  //      	System.setProperty("webdriver.firefox.marionette",path +"\\resource\\geckodriver.exe");
	  //      	driver = new FirefoxDriver();                                                                 //Uncheck Firefox driver if you want to run on firefox
	    
	        	System.setProperty("webdriver.chrome.driver",path +"\\resource\\chromedriver.exe"); 
	        	driver = new ChromeDriver();
	        return driver;
	    }

	    public void getBaseUrl(String baseUrl) {
	        getCurrDriver().get(baseUrl);
	        getCurrDriver().manage().window().maximize();
	    }
	    

}

